import React from 'react'

const Page = () => {
  return (
    <div>payment is successs!</div>
  )
}

export default Page